import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CalcService } from './services/calc.service';



@NgModule({
    declarations: [],
    imports: [
        CommonModule
    ],
    providers: [CalcService]
})
export class CoreModule { }
