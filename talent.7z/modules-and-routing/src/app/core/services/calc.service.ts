export class CalcService {
    plus(x: number, y: number): number {
        return x + y;
    }


    constructor() {
        console.log('CALC SERVICE');
    }
}


