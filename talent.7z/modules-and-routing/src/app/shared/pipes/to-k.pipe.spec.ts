import { ToKPipe } from './to-k.pipe';

describe('ToKPipe', () => {
  it('create an instance', () => {
    const pipe = new ToKPipe();
    expect(pipe).toBeTruthy();
  });
});
