import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomersListComponent } from './components/customers-list/customers-list.component';
import { CustomerDetailsComponent } from './components/customer-details/customer-details.component';
import { CustomersLayoutComponent } from './components/customers-layout/customers-layout.component';



@NgModule({
  declarations: [CustomersListComponent, CustomerDetailsComponent, CustomersLayoutComponent],
  imports: [
    CommonModule
  ]
})
export class CustomersModule { }
