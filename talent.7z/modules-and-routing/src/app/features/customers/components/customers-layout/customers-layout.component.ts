import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customers-layout',
  templateUrl: './customers-layout.component.html',
  styleUrls: ['./customers-layout.component.scss']
})
export class CustomersLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
