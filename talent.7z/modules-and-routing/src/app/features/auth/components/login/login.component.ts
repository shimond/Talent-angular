import { Component, OnInit } from '@angular/core';
import { CalcService } from 'src/app/core/services/calc.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

    constructor(private calcSrrvice: CalcService) {
        console.log(calcSrrvice.plus(10, 300));
    }
    
    ngOnInit(): void {
    }

}
