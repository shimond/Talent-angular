import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddUserComponent } from './components/add-user/add-user.component';
import { LoginComponent } from './components/login/login.component';
import { AuthLayoutComponent } from './components/auth-layout/auth-layout.component';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
    declarations: [AddUserComponent, LoginComponent, AuthLayoutComponent],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild([
            {
                path: '', component: AuthLayoutComponent,
                children:
                    [
                        { path: 'login', component: LoginComponent },
                        { path: 'add', component: AddUserComponent }
                    ]
            }
        ])
    ]
})
export class AuthModule { }
