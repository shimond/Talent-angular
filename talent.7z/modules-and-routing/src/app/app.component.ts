import { Component } from '@angular/core';
import { CalcService } from './core/services/calc.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    title = 'modules-and-routing';

    constructor(private calcService: CalcService) {

    }
}
