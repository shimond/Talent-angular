import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyComponentComponent } from './components/my-component/my-component.component';
import { ListResultComponent } from './components/list-result/list-result.component';
import { BasicDirective } from './directives/basic.directive';
import { SuffixPipe } from './pipes/suffix.pipe';
import { SearchService, SearchMockService } from './services/search.service';
import { CounterComponent } from './components/counter/counter.component';
import { CounterService } from './services/counter.service';
import { CounterWithAsyncComponent } from './components/counter-with-async/counter-with-async.component';

@NgModule({
    declarations: [
        AppComponent,
        MyComponentComponent,
        ListResultComponent,
        BasicDirective,
        SuffixPipe,
        CounterComponent,
        CounterWithAsyncComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule
    ],
    providers: [{
        provide: SearchService,
        useClass: SearchMockService
    }],
    bootstrap: [AppComponent]
})
export class AppModule { }
