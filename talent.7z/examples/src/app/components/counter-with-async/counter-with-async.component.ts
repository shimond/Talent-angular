import { Component, OnInit } from '@angular/core';
import { CounterService } from 'src/app/services/counter.service';
import { Subscription, Observable } from 'rxjs';
import { map, filter, debounceTime } from 'rxjs/operators';

@Component({
    selector: 'app-counter-with-async',
    templateUrl: './counter-with-async.component.html',
    styleUrls: ['./counter-with-async.component.scss']
})
export class CounterWithAsyncComponent implements OnInit {
    count$: Observable<number>;
    plus() {
        this.counterService.plus();
    }

    minus() {
        this.counterService.minus();
    }

    constructor(private counterService: CounterService) {
    }

    ngOnInit(): void {
        this.count$ = this.counterService.counterChanged.pipe(
            //filter(x => x % 5 === 0)
            //debounceTime(500)
        );
    }
}
