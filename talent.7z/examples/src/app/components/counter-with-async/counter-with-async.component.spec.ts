import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CounterWithAsyncComponent } from './counter-with-async.component';

describe('CounterWithAsyncComponent', () => {
  let component: CounterWithAsyncComponent;
  let fixture: ComponentFixture<CounterWithAsyncComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CounterWithAsyncComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CounterWithAsyncComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
