import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-list-result',
    templateUrl: './list-result.component.html',
    styleUrls: ['./list-result.component.scss']
})
export class ListResultComponent implements OnInit {
    @Input() result: string[] = [];
    @Input() selectedItem = null;
    @Output() itemSelected = new EventEmitter<string>();

    constructor() { }

    ngOnInit(): void {
    }

    onItemSelect(item: string) {
        this.itemSelected.emit(item);
    }
}
