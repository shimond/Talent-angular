import { Component, OnInit, OnDestroy } from '@angular/core';
import { CounterService } from 'src/app/services/counter.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-counter',
    templateUrl: './counter.component.html',
    styleUrls: ['./counter.component.scss'],
})
export class CounterComponent implements OnInit, OnDestroy {
    count = 0;
    sub: Subscription;
    plus() {
        this.counterService.plus();
    }

    minus() {
        this.counterService.minus();
    }

    constructor(private counterService: CounterService) {
    }

    ngOnInit(): void {
        this.sub = this.counterService.counterChanged.subscribe(c => {
            if (c % 2 === 0) {
                this.count = c;
            }
            console.log('Changed.', this.count);
        }
        );
    }

    ngOnDestroy() {
        if (this.sub) {
            this.sub.unsubscribe();
        }
    }
}
