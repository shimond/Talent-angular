import { Component, OnInit } from '@angular/core';
import { SearchService } from 'src/app/services/search.service';

@Component({
    selector: 'app-my-component',
    templateUrl: './my-component.component.html',
    styleUrls: ['./my-component.component.scss']
})
export class MyComponentComponent implements OnInit {
    searchWord = '';
    searchResult: string[] = [];
    isBusy = false;
    selectedWord: string = null;
    birthdate = new Date();

    constructor(private searchService: SearchService) { }

    ngOnInit(): void {

    }

    search() {
        this.isBusy = true;
        this.searchResult = [];
        setTimeout(() => {
            this.searchResult = this.searchService.getResult(this.searchWord);
            this.selectedWord = this.searchResult[3];
            this.isBusy = false;
        }, 1500);
    }

    onItemSelected(selectedItem: string) {
        this.selectedWord = selectedItem;
    }
}
