import { BasicDirective } from './basic.directive';

describe('BasicDirective', () => {
  it('should create an instance', () => {
    const directive = new BasicDirective();
    expect(directive).toBeTruthy();
  });
});
