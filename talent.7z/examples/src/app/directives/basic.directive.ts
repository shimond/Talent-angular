import { Directive, HostListener, HostBinding } from '@angular/core';

@Directive({
    selector: '[appBasic]'
})
export class BasicDirective {


    @HostBinding('style.color') color = 'black';

    @HostListener('click') test() {
        this.color = 'red';
    }


    constructor() {
        console.log('BasicDirective Created!');

    }

}
