import { Subject, BehaviorSubject } from 'rxjs';

export class CounterService {
    private count = 0;
    private counterChangedSubject = new BehaviorSubject<number>(0);

    get counterChanged() {
        return this.counterChangedSubject.asObservable();
    }
    plus() {
        this.count++;
        this.counterChangedSubject.next(this.count);
    }

    minus() {
        this.count--;
        this.counterChangedSubject.next(this.count);
    }

    constructor(){
        console.log('Service created');
    }
}
