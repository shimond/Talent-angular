export class SearchService {
    getResult(word: string): string[] {
        const searchResult = [];
        for (let i = 0; i < 10; i++) {
            searchResult.push(word + i);
        }
        return searchResult;
    }
}


export class SearchMockService {
    getResult(word: string): string[] {
        const searchResult = [];
        for (let i = 0; i < 21; i++) {
            searchResult.push(i + word + i);
        }
        return searchResult;
    }
}
