import { SuffixPipe } from './suffix.pipe';

describe('SuffixPipe', () => {
  it('create an instance', () => {
    const pipe = new SuffixPipe();
    expect(pipe).toBeTruthy();
  });
});
