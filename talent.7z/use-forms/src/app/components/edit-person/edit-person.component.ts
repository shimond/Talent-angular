import { Component, OnInit } from '@angular/core';
import { Person } from 'src/app/models/person.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'app-edit-person',
    templateUrl: './edit-person.component.html',
    styleUrls: ['./edit-person.component.scss']
})
export class EditPersonComponent implements OnInit {

    personToEdit: Person;
    personForm: FormGroup;

    constructor(private formBuilder: FormBuilder) { }

    ngOnInit(): void {
        this.personToEdit = { name: 'David', age: 30, email: 'david@gmail.com' };

        this.personForm = this.formBuilder.group({
            name: [this.personToEdit.name, Validators.required],
            age: [this.personToEdit.age, Validators.max(90)],
            email: [this.personToEdit.email]
        });

    }

    save() {
        this.personToEdit = this.personForm.value;
    }

}
